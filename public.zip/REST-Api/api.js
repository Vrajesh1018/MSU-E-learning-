
const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect("mongodb://localhost:27017/student");

const studentSchema = new mongoose.Schema({
    PRN : Number,
    Email : String,
    Password : String,
    Name : String
});

const Student  = mongoose.model("student",studentSchema);


  app.route("/api")

   .get((req,res)=>{

        Student.find({},(err,students)=>{
            if(!err){
                console.log(students);
                res.send(students);
            }

        });
    })
    .post((req,res)=>{
        console.log(req.body);
        var newPRN = req.body.prn;
        var mail = req.body.mail;
        var pass = req.body.password;
        var name = req.body.name;

        const newStudent = new Student({
            PRN : newPRN,
            Email : mail,
            Password : pass,
            Name : name
        });


        newStudent.save((err)=>{
            if(!err){
                res.send("Data saved !!!");
                console.log("Data saved sucessfully !!!");
            }
            else
            console.log(err);

        });


    });




app.listen(4000,()=>{
    console.log("Server has started on port 4000 for API");
});
