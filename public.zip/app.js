
const express = require("express");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const axios = require('axios').default;


const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));




// Home route
app.get("/", (req, res) => {

    console.log(__dirname);
    res.sendFile(__dirname + "/index.html");

    console.log(req.body.createAccount);
});


// Register Route
app.get("/register", (req, res) => {


    res.sendFile(__dirname + "/register.html");


});

app.post("/register", (req, res) => {

    console.log(req.body);

    axios.post('http://localhost:4000/api', {
        prn: req.body.registerPrn,
        mail: req.body.registerEmail,
        password: req.body.registerPassword,
        name: req.body.registerName
    })
        .then(function (response) {
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });



    res.redirect("/");

});



app.listen(3000, () => {

    console.log("server has started on port 3000");
});